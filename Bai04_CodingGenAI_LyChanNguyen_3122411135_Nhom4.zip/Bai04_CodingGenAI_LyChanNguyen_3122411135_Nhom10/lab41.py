from functools import reduce

def get_geometric_mean(*nums: float) -> float:
    Calculate the geometric mean of a sequence of numbers.
    The geometric mean is the nth root of the product of n numbers.
    Args:
        *nums (float): Variable length argument list of numbers.
    Returns:
        float: The geometric mean of the input numbers.
    Raises:
        ValueError: If the sequence is empty.
        ValueError: If the product is negative and the count of numbers is even
                    (which would result in taking an even root of a negative number).
    Examples:
        >>> get_geometric_mean(2, 8)
        4.0
        >>> get_geometric_mean(1, 2, 3, 4, 5)
        2.605171084697352
        >>> get_geometric_mean()
        ValueError: Cannot calculate geometric mean of empty sequence
    """
    Get the geometric mean of a sequence of numbers
    """

    if not nums:
        raise ValueError("Cannot calculate geometric mean of empty sequence")

    product = reduce(lambda a, b: a * b, nums)

    if product < 0 and len(nums) % 2 == 0:
        raise ValueError("Cannot calculate geometric mean")

    return pow(product, 1 / len(nums))