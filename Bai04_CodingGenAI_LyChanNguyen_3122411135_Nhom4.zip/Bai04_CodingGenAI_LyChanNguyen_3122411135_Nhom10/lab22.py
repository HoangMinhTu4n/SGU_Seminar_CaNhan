import ollama

prompt = "You are a hiring manager at a tech company. What is the Two Sum problem?"

# Response 1
response1 = ollama.generate(
    model="llama3",
    prompt=prompt,
    options={
        "temperature": 2,
        "num_predict": 100
    }
)

# Response 2
response2 = ollama.generate(
    model="llama3",
    prompt=prompt,
    options={
        "temperature": 2,
        "num_predict": 100
    }
)

# Response 3
response3 = ollama.generate(
    model="llama3",
    prompt=prompt,
    options={
        "temperature": 2,
        "num_predict": 100
    }
)

print("Output 1:")
print(response1["response"])

print("\nOutput 2:")
print(response2["response"])

print("\nOutput 3:")
print(response3["response"])