from lab41 import get_geometric_mean
import pytest

def test_geometric_mean_two_numbers():
    assert get_geometric_mean(2, 8) == 4.0


def test_geometric_mean_three_numbers():
    assert get_geometric_mean(1, 2, 4) == 2.0


def test_geometric_mean_single_number():
    assert get_geometric_mean(5) == 5.0


def test_geometric_mean_all_ones():
    assert get_geometric_mean(1, 1, 1) == 1.0


def test_geometric_mean_identical_numbers():
    assert get_geometric_mean(3, 3, 3, 3) == 3.0


def test_geometric_mean_empty_sequence():
    with pytest.raises(ValueError, match="Cannot calculate geometric mean of empty sequence"):
        get_geometric_mean()


def test_geometric_mean_negative_even_count():
    with pytest.raises(ValueError, match="Cannot calculate geometric mean"):
        get_geometric_mean(-2, 8)


def test_geometric_mean_negative_odd_count():
    result = get_geometric_mean(-2, 2, 4)
    assert result == pytest.approx(2.0 ** (1/3) * (-1) ** (1/3), rel=1e-9)


def test_geometric_mean_floats():
    assert get_geometric_mean(1.5, 4.0) == pytest.approx(2.449489742783178, rel=1e-9)


def test_geometric_mean_large_numbers():
    result = get_geometric_mean(100, 1000)
    assert result == pytest.approx(316.227766, rel=1e-5)
    def test_geometric_mean_two_floats():
        assert get_geometric_mean(2.5, 6.25) == pytest.approx(3.952847075, rel=1e-9)


    def test_geometric_mean_many_numbers():
        assert get_geometric_mean(1, 2, 4, 8, 16) == pytest.approx(4.0, rel=1e-9)


    def test_geometric_mean_very_small_numbers():
        assert get_geometric_mean(0.001, 0.01, 0.1) == pytest.approx(0.01, rel=1e-9)


    def test_geometric_mean_mixed_small_large():
        assert get_geometric_mean(0.1, 100) == pytest.approx(3.162277660, rel=1e-9)


    def test_geometric_mean_negative_three_numbers():
        result = get_geometric_mean(-8, 1, 1)
        assert result == pytest.approx(-2.0, rel=1e-9)


    def test_geometric_mean_two_negatives():
        assert get_geometric_mean(-4, -16) == pytest.approx(8.0, rel=1e-9)