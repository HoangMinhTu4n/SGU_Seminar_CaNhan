import ollama

prompt = "Explain the FizzBuzz problem."

response = ollama.generate(
    model="llama3",
    prompt=prompt
)

print(response["response"])