import ollama

# Step 1: User prompt (function signature)
USER_PROMPT = """
def print_fibonacci_sequence(n: int) -> None:
"""

# Step 2: System prompt
SYSTEM_PROMPT = """
You will be provided with a Python function signature.
Your task is to implement the function.
Return code only.
"""

# Step 3: Wrap instruction
def get_code_with_instructions(code: str) -> str:
    return code + "\n# Complete this code"


if __name__ == "__main__":

    prompt = SYSTEM_PROMPT + "\n" + get_code_with_instructions(USER_PROMPT)

    # Step 4: call model
    response1 = ollama.generate(
        model="llama3",
        prompt=prompt,
        options={"temperature": 1}
    )

    response2 = ollama.generate(
        model="llama3",
        prompt=prompt,
        options={"temperature": 1}
    )

    outputs = [response1["response"], response2["response"]]

    # Step 5: extract code
    for i, output in enumerate(outputs):
        print(f"Output {i+1}:")

        try:
            suggested_code = output.split("```")[1]
            print(suggested_code)
        except IndexError:
            print(output)

        print("\n")