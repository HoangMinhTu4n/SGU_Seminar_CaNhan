import random

# Set seed for reproducibility
random.seed(42)

print("Multiplication Quiz")

for i in range(10):
    a = random.randint(1, 12)
    b = random.randint(1, 12)

    question = f"What is {a} x {b}? "

    try:
        answer = int(input(question))
    except ValueError:
        print("Invalid input. Please enter a number.")
        continue

    if answer == a * b:
        print("Well done!")
    else:
        print(f"No. The correct answer is {a*b}.")