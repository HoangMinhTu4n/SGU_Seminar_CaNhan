# Part 1: Open the chat window and ask to explain the geometric mean.

# Part 2: Implement the geometric mean function for two floating-point numbers.
def get_geometric_mean_of_two_numbers(
    a: float,
    b: float,
) -> float:
    """
    Calculate the geometric mean of two floating-point numbers.

    Parameters:
    a (float): The first number.
    b (float): The second number.

    Returns:
    float: The geometric mean of a and b.
    """
    # Geometric mean is calculated as the square root of the product of the two numbers
    return (a * b) ** 0.5

# Part 3: Call
num1: float = 5.0
num2: float = 20.0
print(f"The geometric mean of {num1} and {num2} is: {get_geometric_mean_of_two_numbers(num1, num2)}")

