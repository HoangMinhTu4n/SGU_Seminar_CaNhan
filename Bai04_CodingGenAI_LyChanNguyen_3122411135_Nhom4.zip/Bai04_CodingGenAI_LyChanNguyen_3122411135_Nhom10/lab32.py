def get_geometric_mean(*nums):
    """
    Calculate the geometric mean of a list of numbers.

    Parameters:
    *nums: A variable number of numerical arguments.

    Returns:
    float: The geometric mean of the input numbers.
    """
    product = 1
    count = len(nums)

    for num in nums:
        product *= num

    return product ** (1 / count)

nums = [5.0, 20.0, 10.0]

print(get_geometric_mean(*nums))